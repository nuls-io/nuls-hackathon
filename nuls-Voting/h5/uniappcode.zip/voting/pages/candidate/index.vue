<template>
	<view class="content">
		<left-drawer ref="leftdrawer"></left-drawer>
		<view class="uni-padding-wrap uni-common-mt">
			<view class="candidatetitle">应征候选人</view>
			<form @submit="formSubmit" @reset="formReset">
			               
				<view class="uni-form-item uni-column">
			        <view class="title">候选人姓名</view>
			        <input class="uni-input" name="name" placeholder="请输入投票活动名称" />
				</view>
				
				<view class="uni-form-item uni-column">
				    <view class="title">自我介绍</view>
				    <view>    
				        <view class="uni-textarea" >
				                    <textarea placeholder-style="color:#888" name='introduce' placeholder="请输入应征作品详细介绍"/>
				        </view>
				     </view>
				</view>
				
				<view class="uni-form-item uni-column">
				    <view class="title">资源链接</view>
				    <view>    
				        <view class="uni-textarea" >
				            <textarea placeholder-style="color:#888" name='resource' placeholder="请视频等资源链接,每行一个"/>
				        </view>
				     </view>
				</view>
				
			    <view class="uni-btn-v">
			        <button formType="submit">应征候选人</button>
			        <button type="default" formType="reset">重置</button>
			    </view>
			</form>
		</view>
		
	</view>
</template>

<script>
import leftdrawer from "@/pages/common/leftdrawer/leftdrawer.vue"
export default {
	components:{
	            'left-drawer':leftdrawer,
	        },
	onNavigationBarButtonTap() {
		    console.log("点击了自定义按钮");
			if(this.$refs.leftdrawer.isActiveleftDrawer == false)		
				this.$refs.leftdrawer.isActiveleftDrawer  = true;
			else
			    this.$refs.leftdrawer.isActiveleftDrawer  = false;
	},
	
	methods:{
		formSubmit: function(e) {
			var formdata = e.detail.value
			formdata.user_id = '50000000002';
			formdata.vote_event_id = '1';
			const requestTask = uni.request({
			    url: 'http://nulsvoting.wanghx.top/phalapi/public/index.php?s=App.Vote.NewCandidate', 
			    data: formdata,
			    success: function(res) {
			        console.log(res.data);
			    }
			});
		            console.log('form发生了submit事件，携带数据为：' + JSON.stringify(e.detail.value))
		        },
	}
		
}
</script>
<style>
	.content {
		display: flex;
		flex-direction: column;
		align-items: center;
		justify-content: center;
	}
	
	.logo {
		height: 200upx;
		width: 200upx;
		margin-top: 200upx;
		margin-left: auto;
		margin-right: auto;
		margin-bottom: 50upx;
	}
	
	.text-area {
		display: flex;
		justify-content: center;
	}
	
	.candidatetitle {
		font-size: 50upx;
		color: #222;
		text-align: center;
	}
	
	.title{
		font-size: 36upx;
		color: #222;
	}
	
	.uni-textarea{
		min-height: 100upx;
		border: 1upx #3F536E solid;
		margin-left: 10upx;
	
	}
	
	
</style>
