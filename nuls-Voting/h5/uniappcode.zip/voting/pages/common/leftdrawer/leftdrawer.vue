<template>
	<view>
		<uni-drawer :visible="isActiveleftDrawer" @close="closeleftDrawer" >
		    <view style="padding:30rpx;">
		        <view class="uni-title">投票选举</view>
				<view class="leftdrawer-close" @tap="closeleftDrawer">&#xe69a;</view>
		        <view class="uni-list uni-common-mt">
		            <view class="uni-list-cell" hover-class="uni-list-cell-hover" @tap="opennewvote">
		                <view class="uni-list-cell-navigate uni-navigate-right">新建投票选举活动</view>
		            </view>
		            <view class="uni-list-cell uni-list-cell-last" hover-class="uni-list-cell-hover" @tap="becandidate">
		                <view class="uni-list-cell-navigate uni-navigate-right">成为候选人</view>
		            </view>
					<view class="uni-list-cell uni-list-cell-last" hover-class="uni-list-cell-hover" @tap="tovote">
					    <view class="uni-list-cell-navigate uni-navigate-right">进行投票</view>
					</view>
		        </view>
		    </view>
		</uni-drawer>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				isActiveleftDrawer: false,
			}
		},
		methods: {
			closeleftDrawer: function(e){
						console.log("点击了X按钮");
						this.isActiveleftDrawer = false;
						
			},
			opennewvote: function(e){
				this.isActiveleftDrawer = false;
				uni.redirectTo({
				                    url: '../index/index',
				                });
			},
			becandidate: function(e){
				this.isActiveleftDrawer = false;
				uni.redirectTo({
				                    url: '../candidate/index',
				                });
			},
			tovote: function(e){
				this.isActiveleftDrawer = false;
				uni.redirectTo({
				                    url: '../vote/index',
				                });
			}
			
		},
		
	}
</script>

<style>
	.uni-title{
		width: 70%;
		float: left;
	}
	@font-face {
	        font-family: 'iconfont';
	        src: local('图形文字'), url('../../../static/iconfont.ttf') format('truetype');
	}	
	.leftdrawer-close{
		width: 15%;
		float: right;
		font-family: 'iconfont';
		font-size: 40upx;	
	}

</style>
