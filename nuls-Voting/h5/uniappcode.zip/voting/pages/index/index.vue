<template>

	<view class="content">
		
		<left-drawer ref="leftdrawer"></left-drawer>
		
		<view class="uni-padding-wrap uni-common-mt">
		<view class="votetitle">新建投票选举活动</view>
		<form @submit="formSubmit" @reset="formReset">
		               
			<view class="uni-form-item uni-column">
		        <view class="title">投票标题</view>
		        <input class="uni-input" name="title" placeholder="请输入投票活动名称" />
			</view>
			
			<view class="uni-form-item uni-column">
			    <view class="title">详细介绍</view>
			    <view>    
			        <view class="uni-textarea" >
			                    <textarea placeholder-style="color:#888" name='detail' placeholder="请输入投票详细介绍"/>
			        </view>
			     </view>
			</view>
			
			<view class="uni-form-item uni-column">
			    <view class="title">资源链接</view>
			    <view>    
			        <view class="uni-textarea" >
			            <textarea placeholder-style="color:#888" name='resource' placeholder="请视频等资源链接,每行一个"/>
			        </view>
			     </view>
			</view>
			
		    <view class="uni-btn-v">
		        <button formType="submit">提交投票活动</button>
		        <button type="default" formType="reset">重置</button>
		    </view>
		</form>
	</view>
	</view>
</template>

<script>
// import uniDrawer from "@/components/uni-drawer/uni-drawer.vue"
import leftdrawer from "@/pages/common/leftdrawer/leftdrawer.vue"
	export default {	
		// components: {uniDrawer},
		components:{
		            'left-drawer':leftdrawer,
		        },
		data() {
			return {
				pickerHidden: true,
				chosen: '',
				// isActiveleftDrawer: false,
				
			}
		},
		onLoad() {
			
		},
		methods: {
			pickerConfirm: function(e) {
			            this.pickerHidden = true
			            this.chosen = e.target.value
			        },
			pickerCancel: function(e) {
			            this.pickerHidden = true
			        },
			pickerShow: function(e) {
			            this.pickerHidden = false
			        },
			formSubmit: function(e) {
				var formdata = e.detail.value
				formdata.user_id = '50000000002';
				const requestTask = uni.request({
				    url: 'http://nulsvoting.wanghx.top/phalapi/public/index.php?s=App.Vote.NewVoting', 
				    data: formdata,
				    success: function(res) {
				        console.log(res.data);
				    }
				});
			            console.log('form发生了submit事件，携带数据为：' + JSON.stringify(e.detail.value))
			        },
			formReset: function(e) {
			            console.log('清空数据')
			            this.chosen = ''
			        },
			
		},
	onNavigationBarButtonTap() {
	    console.log("点击了自定义按钮");
		if(this.$refs.leftdrawer.isActiveleftDrawer == false)		
			this.$refs.leftdrawer.isActiveleftDrawer  = true;
		else
		    this.$refs.leftdrawer.isActiveleftDrawer  = false;
	},
	
	
	
		
	}
</script>

<style>
	.content {
		display: flex;
		flex-direction: column;
		align-items: center;
		justify-content: center;
	}

	.logo {
		height: 200upx;
		width: 200upx;
		margin-top: 200upx;
		margin-left: auto;
		margin-right: auto;
		margin-bottom: 50upx;
	}

	.text-area {
		display: flex;
		justify-content: center;
	}

	.votetitle {
		font-size: 50upx;
		color: #222;
		text-align: center;
	}
	
	.title{
		font-size: 36upx;
		color: #222;
	}
	
	.uni-textarea{
		min-height: 100upx;
		border: 1upx #3F536E solid;
		margin-left: 10upx;
	
	}
	

</style>
