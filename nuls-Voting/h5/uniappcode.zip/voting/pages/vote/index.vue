<template>
	<view class="content">
		<left-drawer ref="leftdrawer"></left-drawer>
		<view class="uni-padding-wrap uni-common-mt">
			<view class="votetitle">投票</view>
			<br/>
			<view class="title">投票人账号地址:</view>
			<input type="text" value="" placeholder="请输入投票人账号地址"/>
			<br/>
			<view class="title">投票选举项目名称:大宋国际城项目得标</view>
			<view class="title">投票选举项目介绍:</view>
			<view class="content">新华都商学院创业与创新MBA教育项目，是中国开展MBA教育20余年来，教育部批准的第一个以创业与创新为方向的MBA学位点，已有七年的办学历史，在MBA教育领域独树一帜，已成为国内创业创新特色教育的第一品牌。
新华都商学院整合政府、企业、社会等多方面资源，突破传统的教学模式，通过系统的知识传授和创业创新实践等体验式学习方式，启迪学生的创新性思维，释放学生的创业智慧和能量，培养具有社会责任感的创业与创新领导者。</view>
			<view class="itemblock" v-for="(item,index) in candidateArray" :key="item.id">
				<view class="item">候选人姓名:{{item.name}}</view>
				<view class="item">候选人介绍:{{item.introduce}}</view>
				<view class="item">其他资料:{{item.resource}}</view>
				<view class="item">得票数:{{item.tickes}}</view>
				<button class= "toupiao" type="default" size="mini">投票</button>
				
			</view>
			
			
		</view>
	</view>
</template>

<script>
	import leftdrawer from "@/pages/common/leftdrawer/leftdrawer.vue"
	export default {
		data(){
			return {
				candidateArray:[
					{name:'张三',introduce:'大家好,我是朱士进,我是一个活泼开朗的女孩,我最喜欢的就是主持人,我梦想着有一天能够象欧阳夏丹、白岩松这些著名的主持人那样,站在灯光四射的舞台上',resource:'https://www.51miz.com/ppt/ziwojieshao/165740.html',tickes:567},
					{name:'李四',introduce:'血型:A 个人简介爱好广泛,日常撩妹,爱逛街爱看剧,懂得照顾别人,爱旅行。',resource:'https://www.51miz.com/ppt/gongsijieshao/162870.html',tickes:329}
				]
			}
			
		},
		components:{
		            'left-drawer':leftdrawer,
		        },
		onNavigationBarButtonTap() {
			    console.log("点击了自定义按钮");
				if(this.$refs.leftdrawer.isActiveleftDrawer == false)		
					this.$refs.leftdrawer.isActiveleftDrawer  = true;
				else
				    this.$refs.leftdrawer.isActiveleftDrawer  = false;
		},
			
	}
</script>

<style>
	.content {
		display: flex;
		flex-direction: column;
		align-items: center;
		justify-content: center;
	}
	
	.logo {
		height: 200upx;
		width: 200upx;
		margin-top: 200upx;
		margin-left: auto;
		margin-right: auto;
		margin-bottom: 50upx;
	}
	
	.text-area {
		display: flex;
		justify-content: center;
	}
	
	.votetitle {
		font-size: 50upx;
		color: #222;
		text-align: center;
	}
	
	.title{
		font-size: 36upx;
		color: #222;
	}
	
	.itemblock{
		width: 100%;
		margin: 30upx 0;
		background-color: #eee;
		float: left;
	}
	.item{	
		font-size: 30upx;
		color: #333;
		margin: 5upx ;
		float: left;
		word-break:break-all;
	}
	
	.uni-textarea{
		min-height: 100upx;
		border: 1upx #3F536E solid;
		margin-left: 10upx;
	
	}
	
	.toupiao{
		float: right;
		margin-right: 10upx;
		margin-bottom: 10upx;
		background-color: #00EFCF;
	}
	
</style>
